<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <h1>practica3</h1>


        <section>
        <h3>seccion 1</h3>

        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="img/imagen1" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Araña Viuda Negra</h5>
                    <p class="card-text">Some quick example text to build on the card 
                        title and make up the bulk of the card’s content.</p>
                    <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>

                </div>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="img/imagen2" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Araña Violinista</h5>
                        <p class="card-text">Some quick example text to build on the card 
                            title and make up the bulk of the card’s content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="img/imagen3" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Araña Lobo</h5>
                            <p class="card-text">Some quick example text to build on the card 
                                title and make up the bulk of the card’s content.</p>
                            <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--hr es para aplicar una linea horizontal divisora-->
        <hr>
    </section>

    <section>
        <section>
        <h3>seccion 2</h3>

        <div class="container">
            <div class="row">

                    <?php 

                        for ($i=1; $i <5 ; $i++){

                            switch ($i) {
                            case 1:
                                $text = "probando 1";
                                break;

                            case 2:
                                $text = "probando 2";
                                break;

                            case 3:
                                $text = "probando 3";
                                break;

                            default:
                                $text = "informacion erronea";
                                break;
                        }

                    ?>
                        <div class="col">
                            <div class="card" style="width: 18rem;">
                                <img src="img/imagen<?php echo $i; ?>.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">tarjeta # <?php echo $i?> </h5>
                                    <p class="card-text"><?php echo $text; ?></p>
                                    <a href="#" class="btn btn-primary">Go somewhere</a>
                                </div>
                            </div>
                        </div>

                    <?php
                        }

                    ?>
                

                </div>
            </div>
        </div>
        </section>


    </section>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>