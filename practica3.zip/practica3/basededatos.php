<?php

$db = new PDO('sqlite:database.db');

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Crear tabla automaticamente 
$db->exec("
    CREATE TABLE IF NOT EXISTS usuarios(
    id INTERGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    email TEXT NOT NULL,
    telefono INTEGER
    )
");

$db->exec("
    INSERT INTO usuarios (nombre, email, telefono)
    VALUES ("Carlos", 34, null)
");

echo "Base de datos lista";
?>