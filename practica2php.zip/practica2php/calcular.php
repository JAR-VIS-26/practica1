<?php

$numero1 = $_POST["numero1"];
$numero2 = $_POST["numero2"];
$operacion = $_POST["operacion"];

echo "<h1>Resultado</h1>";

if ($operacion == "suma") {

    $resultado = $numero1 + $numero2;
    echo "<p>La suma de $numero1 + $numero2 es: <strong>$resultado</strong></p>";

} elseif ($operacion == "resta") {

    $resultado = $numero1 - $numero2;
    echo "<p>La resta de $numero1 - $numero2 es: <strong>$resultado</strong></p>";

} elseif ($operacion == "multiplicacion") {

    $resultado = $numero1 * $numero2;
    echo "<p>La multiplicación de $numero1 × $numero2 es: <strong>$resultado</strong></p>";

} elseif ($operacion == "division") {

    if ($numero2 == 0) {
        echo "<p>No se puede dividir entre cero.</p>";
    } else {
        $resultado = $numero1 / $numero2;
        echo "<p>La división de $numero1 ÷ $numero2 es: <strong>$resultado</strong></p>";
    }

}

?>
