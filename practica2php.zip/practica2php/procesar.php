<?php

$nombre = $_POST["nombre"];
$edad = $_POST["edad"];
$correo = $_POST["correo"];

echo "<h1>Información del usuario</h1>";

echo "<p>Hola, <strong>" . htmlspecialchars($nombre) . "</strong>.</p>";

echo "<p>Tu correo electrónico es: " . htmlspecialchars($correo) . "</p>";

echo "<p>Tu edad es: " . $edad . " años.</p>";

if ($edad >= 18) {
    echo "<p>Eres <strong>mayor de edad</strong>.</p>";
} else {
    echo "<p>Eres <strong>menor de edad</strong>.</p>";
}

?>
